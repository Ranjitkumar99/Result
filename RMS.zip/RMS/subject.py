from tkinter import*
from PIL import Image,ImageTk  # pip install pillow
from tkinter import ttk,messagebox
import sqlite3
class Subject:
    def __init__(self,root):
        self.root=root
        self.root.title("Student Result Management System")
        self.root.geometry("1200x480+80+170")
        self.root.config(bg="#BCB88A")
        self.root.focus_force()

         # #====content__Window====
        self.bg_img=Image.open("images\kp2.jpg")
        self.bg_img=self.bg_img.resize((1300,500),Image.LANCZOS)
        self.bg_img=ImageTk.PhotoImage(self.bg_img)

        self.lbl_bg=Label(self.root,image=self.bg_img).place(x=0,y=0) 
        

        # # =====title=====#
        title=Label(self.root,text="SUBJECT   DETAILS",font=("goudy old style",30,"bold"),bg="brown",fg="white").place(x=0,y=20,width=1200,height=40)

# =======================================================================================================================================================================================
        self.var_Branch=StringVar()
        self.var_Department=StringVar()
        self.var_Semester=StringVar()
        self.var_Year=StringVar()
        self.var_Subject=StringVar()
        # self.var_search=StrngVar()

# $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
        lbl_branch=Label(self.root,text="Branch",font=("goudy old style",20,'bold'),bg='light yellow').place(x=10,y=80)
        lbl_department=Label(self.root,text="Department",font=("goudy old style",20,'bold'),bg='light yellow').place(x=10,y=130)
        lbl_semester=Label(self.root,text="Semester",font=("goudy old style",20,'bold'),bg='light yellow').place(x=10,y=180)
        lbl_year=Label(self.root,text="Year",font=("goudy old style",20,'bold'),bg='light yellow').place(x=10,y=230)
        lbl_subject=Label(self.root,text="Subject",font=("goudy old style",20,'bold'),bg='light yellow').place(x=10,y=280)

# *************************************************************************************************************************************************************************************************
        self.txt_branch=ttk.Combobox(self.root,textvariable=self.var_Branch,values=("BE","B.Tech","Bsc","Bca","B.com","Agriculture","Diploma"),font=("goudy old style",15,'bold'),state='readonly',justify=CENTER)
        self.txt_branch.place(x=160,y=80,width=250)
        self.txt_branch.set("Select")

        self.txt_department=ttk.Combobox(self.root,textvariable=self.var_Department,values=("CSE","EE/ECE","CE","ME","Nursing","GNM","B.P.T"),font=("goudy old style",15,'bold'),state='readonly',justify=CENTER)
        self.txt_department.place(x=170,y=130,width=240)
        self.txt_department.set("Select")

        self.txt_semester=ttk.Combobox(self.root,textvariable=self.var_Semester,values=("1st","2nd","3rd","4th","5th","6th","7th","8th"),font=("goudy old style",15,'bold'),state='readonly',justify=CENTER)
        self.txt_semester.place(x=170,y=180,width=240)
        self.txt_semester.set("Select")

        self.txt_year=ttk.Combobox(self.root,textvariable=self.var_Year,values=("1st","2nd","3rd","4th","5th","6th","7th","8th"),font=("goudy old style",15,'bold'),state='readonly',justify=CENTER)
        self.txt_year.place(x=170,y=230,width=240)
        self.txt_year.set("Select")

        self.txt_subject=ttk.Combobox(self.root,textvariable=self.var_Subject,values=("Python","PPL","DBMS","CN","TOC","ACA","ANATOMY","Microorganism","Linux/Unix","Microprocessor","Building Manufacture"),font=("goudy old style",15,'bold'),state='readonly',justify=CENTER)
        self.txt_subject.place(x=170,y=280,width=240)
        self.txt_subject.set("Select")

# //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
        btn_add=Button(self.root,text="Submit",font=("Arial",15,"bold"),bg="violet",activebackground="orange",cursor="hand2").place(x=100,y=400,width=120,height=35)
        btn_clear=Button(self.root,text="Clear",font=("Arial",15,"bold"),bg="orange",activebackground="violet",cursor="hand2").place(x=280,y=400,width=120,height=35)

# &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&# #====content__Window====
     

        self.pk3_img=Image.open("images\pk3.jpg")
        self.pk3_img=self.pk3_img.resize((560,390),Image.LANCZOS)
        self.pk3_img=ImageTk.PhotoImage(self.pk3_img)

        self.lbl_pk3=Label(self.root,image=self.pk3_img).place(x=600,y=70)

# {}{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
        
        def add(self):
                con=sqlite3.connect(database="rms.db")
                cur=con.cursor()
                try:
                        if self.var_Branch.get()=="":
                                messagebox.showerror("Error","Please first select branch",parent=self.root)
                        else:
                                cur.execute("select * from subject where branch=? and department=?",(self.var_Branch.get(),self.var_Department.get(),))
                                row=cur.fetchone()
                                print(row)
                       
                        con.commit()
                        messagebox.showinfo("Success",parent=self.root)
                        
                        
                except Exception as ex:
                        messagebox.showerror("Error",f"Error due to {str(ex)}")    


        def clear(self):
                
                self.var_Branch.set("Select"),
                self.var_Department.set(""),
                self.var_Semester.set(""),
                self.var_Year.set(""),
                self.var_Subject.set(""),
                self.show()
        
  
if __name__=="__main__":
    root=Tk()
    obj=Subject(root)
    root.mainloop()