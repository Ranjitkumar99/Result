def add_course(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=CourseClass(self.new_win)
         
    def add_student(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=Student(self.new_win)

    def add_subject(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=Subject(self.new_win)

    def add_result(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=ResultClass(self.new_win)
    
    def add_report(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=ReportClass(self.new_win)

    def add_login(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=Login(self.new_win)
    
    def add_exit(self):
        self.new_win=Toplevel(self.root)
        self.new_obj=Exit(self.new_win)